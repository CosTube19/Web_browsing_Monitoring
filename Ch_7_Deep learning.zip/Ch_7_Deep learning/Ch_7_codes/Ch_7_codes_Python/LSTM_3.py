# Text generation with an LSTM network

# Fitting an LSTM for "text generation" - Part 1
# Clear the environment
for v in dir(): del globals()[v]

# Small LSTM Network to Generate Text
import numpy
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import LSTM
from keras.callbacks import ModelCheckpoint
from keras.utils import np_utils
import sys
import os

# Change the current working directory
os.chdir('/Users/cerulli/Dropbox/Giovanni/Book_Stata_ML_GCerulli/deep/sjlogs')

# Load the ascii text and covert to lowercase
filename = "ThePictureOfDorianGray.txt"
raw_text = open(filename, 'r', encoding='utf-8').read()
raw_text = raw_text.lower()

# Using "set()" generate unique characters from the text and sort them
chars = sorted(list(set(raw_text)))
print(chars)

# Create a dictonary mapping a unique char into a unique integer
char_to_int = dict((c, i) for i, c in enumerate(chars))
print(char_to_int)

# Summarize the properties of the text
n_chars = len(raw_text)
n_vocab = len(chars)
print("Total Characters: ", n_chars)
print("Total Vocab: ", n_vocab)

# Form the input ('dataX') and target ('dataY') encoded as integers
seq_length = 100
dataX = []
dataY = []
for i in range(0, n_chars - seq_length, 1):
	seq_in = raw_text[i:i + seq_length]
	seq_out = raw_text[i + seq_length]
	dataX.append([char_to_int[char] for char in seq_in])
	dataY.append(char_to_int[seq_out])
n_patterns = len(dataX)
print("Total Patterns: ", n_patterns)

# Reshape 'dataX' as tensor to be [observations, seq-length, features]
X = numpy.reshape(dataX, (n_patterns, seq_length, 1))

# Normalize X between [0;1] dividing by the size of the vocabulary
X = X / float(n_vocab)

# Tranfrom the output variable into a matrix of category-dummies 
y = np_utils.to_categorical(dataY)

# Define the LSTM model
model = Sequential()
n_lags = X.shape[1] 
n_features = X.shape[2] 
model.add(LSTM(256, input_shape=(n_lags, n_features)))
model.add(Dropout(0.2))
model.add(Dense(y.shape[1], activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam')

# Define the checkpoint
filepath="weights-improvement-{epoch:02d}-{loss:.4f}.hdf5"
checkpoint = ModelCheckpoint(filepath, monitor='loss', verbose=1, save_best_only=True, mode='min')
callbacks_list = [checkpoint]

# Fit the model
model.fit(X, y, epochs=50, batch_size=64, callbacks=callbacks_list)


# Fitting an LSTM for "text generation" - Part 2
# Generating Text with an LSTM Network

# Load the network weights with smallest loss value
filename = "weights-improvement-34-1.8758.hdf5"
model.load_weights(filename)
model.compile(loss='categorical_crossentropy', optimizer='adam')

# convert the integers back to characters
int_to_char = dict((i, c) for i, c in enumerate(chars))

# pick a random seed
start = numpy.random.randint(0, len(dataX)-1)
pattern = dataX[start]
print("Seed:")
print("\"", ''.join([int_to_char[value] for value in pattern]), "\"")

# Generate 1000 characters starting from a seed sequence
for i in range(1000):
	x = numpy.reshape(pattern, (1, len(pattern), 1))
	x = x / float(n_vocab)
	prediction = model.predict(x, verbose=0)
	index = numpy.argmax(prediction)
	result = int_to_char[index]
	seq_in = [int_to_char[value] for value in pattern] # non dovrebbe servire (da controllare)
	sys.stdout.write(result)
	pattern.append(index)
	pattern = pattern[1:len(pattern)]
print("\nDone.")
# End

